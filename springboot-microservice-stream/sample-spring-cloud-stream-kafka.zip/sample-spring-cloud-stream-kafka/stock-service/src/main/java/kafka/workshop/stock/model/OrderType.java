package kafka.workshop.stock.model;

public enum OrderType {
    SELL, BUY;
}
