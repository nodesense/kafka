package kafka.workshop.order.model;

public enum OrderType {
    SELL, BUY;
}
