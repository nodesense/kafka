delete from "order".orders where id = 'd215b5f8-0249-4dc5-89a3-51fd148cfb17';

delete from "order".payment_outbox where id = '8904808e-286f-449b-9b56-b63ba8351cf2';