package kafka.workshop.services.transactions.controller;

import kafka.workshop.services.transactions.domain.OrderGroup;
import kafka.workshop.services.transactions.producer.TransactionsProducer;
import kafka.workshop.services.transactions.repository.OrderGroupRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/transactions")
public class TransactionsController {

    TransactionsProducer producer;
    OrderGroupRepository repository;

    public TransactionsController(TransactionsProducer producer, OrderGroupRepository repository) {
        this.producer = producer;
        this.repository = repository;
    }

    @PostMapping
    public void sendTransaction(@RequestBody boolean error) throws InterruptedException {
        producer.sendOrderGroup(error);
    }

    @GetMapping
    public List<OrderGroup> findAll() {
        return (List<OrderGroup>) repository.findAll();
    }
}
