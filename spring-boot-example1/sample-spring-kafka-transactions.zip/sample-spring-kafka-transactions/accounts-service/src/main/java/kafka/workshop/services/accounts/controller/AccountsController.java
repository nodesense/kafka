package kafka.workshop.services.accounts.controller;
import kafka.workshop.services.accounts.domain.Account;
import kafka.workshop.services.accounts.repository.AccountRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/accounts")
public class AccountsController {
    AccountRepository  repository;
    public AccountsController(AccountRepository  repository) {

        this.repository = repository;
    }

    @GetMapping
    public List<Account> findAll() {
        return (List<Account>) repository.findAll();
    }

}
