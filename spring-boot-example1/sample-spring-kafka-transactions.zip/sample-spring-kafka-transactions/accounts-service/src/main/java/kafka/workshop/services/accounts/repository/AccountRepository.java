package kafka.workshop.services.accounts.repository;

import org.springframework.data.repository.CrudRepository;
import kafka.workshop.services.accounts.domain.Account;

public interface AccountRepository extends CrudRepository<Account, Long> {
}
