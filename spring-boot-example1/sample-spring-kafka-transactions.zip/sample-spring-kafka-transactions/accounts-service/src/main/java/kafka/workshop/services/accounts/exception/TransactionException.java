package kafka.workshop.services.accounts.exception;

public class TransactionException extends Exception {

    public TransactionException(String message) {
        super(message);
    }

}
